

% joint filtering with weighted mode filter
depth = rgb2gray(imread('venus_census.png'));
guidance = imread('venus.png');
tic;
depth_refined = msmoother(depth,'wmod',10, 0.1, guidance);  % try med, isomed, mod, isomod, wmed, wmod
toc;
figure, imshow([depth, depth_refined]); 


% % filtering with weighted mode filter
% I = imread('noisesyn.png'); 
% tic;
% J = msmoother(I,'wmod');  % try med, isomed, mod, isomod, wmed, wmod
% toc;
% figure, imshow([I, J]); colormap jet;

