function [OUT]=msmoother(img,filter_type,sigma_s,sigma_r,guidance,N)
%MSOOTHER  A piecewise-constant image smoothing framework including: 
%          median filter,
%          mode filter,
%          weighted median filter, 
%          weighted mode filter. 
%          NOTE: Currently only 1-channel input image is supported. 
%
%   MSOOTHER can perform piecewise-constant image smoothing by 
%   integrating existing weighted-average filters (box filter, Gaussian 
%   filter, bilateral filter, guided filter, etc.) with robust norms. 
%   It can approximate (weighted) median filters and (weighted) mode filters. 
%   If you find the code useful, please cite our paper:
%
%   Linchao Bao and Qingxiong Yang, 
%   "Robust Piecewise-Constant Smoothing: M-Smoother Revisited", 
%   arXiv:1410.7580 [cs.CV], 2014.
%
%   Please kindly contact Linchao Bao (linchaobao@gmail.com) for bug report.
%   
%   Usage
%   -----
%   [OUT] = MSOOTHER(img,filter_type,sigma_s,sigma_r,guidance,N)
%   PARAMETERS: 
%             img: input 1-channel image.
%             filter_type: a string indicating which filter type is to use:
%                          'med': median filter with box kernel;
%                          'isomed': median filter with Gaussian kernel;
%                          'mod': mode filter with box kernel;
%                          'isomod': mode filter with Gaussian kernel;
%                          'wmed': weighted median filter with guided kernel;
%                          'wmod': weighted mode filter with guided kernel.
%             sigma_s: spatial parameter for the filter, like the sigma_s 
%                      parameter in bilateral filter. It should be an integer 
%                      number indicating number of pixels. The default value is 5. 
%             sigma_r: range parameter for the filter. like the sigma_r 
%                      parameter in bilateral filter. It should be a real 
%                      number in (0,1). The default value is 0.1.
%             guidance: the guidance image for joint filtering, like that 
%                       in joint bilateral filter. Default is the input image.
%             N: the number of filtering samples for the approximation. 
%                With a larger N, the result will be more accurate but the 
%                speed will be slower. Default value 24. Try 8 or 16 for 
%                faster speed, and try 32 and 64 for more accurate results 
%                (e.g., HDR images). 
%
%   Example
%   -------
%   I = imread('noisesyn.png'); 
%   J = msmoother(I,'wmod'); 
%   figure, imshow([I, J]); colormap jet;

errstr_filtertype = 'Parameter filter_type should be provided: med, isomed, mod, isomod, wmed, wmod';

if ~exist('filter_type', 'var')
    error(errstr_filtertype);
end
if ~exist('sigma_s', 'var')
    sigma_s = 5;
end
if ~exist('sigma_r', 'var')
    sigma_r = 0.1;
end
if ~exist('guidance', 'var')
    guidance = img;
end
if ~exist('N', 'var')
    N = 24;
end

[h,w,c] = size(img);
is_uint8 = strcmpi(class(img), 'uint8');
if c > 1
    img = rgb2gray(img); % Currently only 1-channel image supported
end
if size(guidance,3) > 1
    guidance = rgb2gray(guidance);
end

img = double(img); 
guidance = double(guidance);

Imax = max(img(:));
Imin = min(img(:));
Irange = Imax - Imin;

sigma_s = ceil(sigma_s); 
sigma_r = sigma_r*Irange; 

costvolume = zeros(h,w,N);
Idelta = Irange / (N-1);
Itheta = Imin:Idelta:Imax; % Uniform sampling

% begin filtering
for i = 1:N
    % prepare cost image
    if sum(strcmpi(filter_type, {'med','isomed','wmed'})) > 0
        costimg = abs(Itheta(i)-img); % L1 norm
    elseif sum(strcmpi(filter_type, {'mod','isomod','wmod'})) > 0
        tmpimg = (Itheta(i)-img); tmpimg = tmpimg .* tmpimg;
        tmpval = 0.64*sigma_r; tmpval = tmpval*tmpval;
        costimg = 1 - exp(-tmpimg ./ tmpval); % Negative Gauss
    else
        error(errstr_filtertype);
    end
    
    % filtering 
    if sum(strcmpi(filter_type, {'med','mod'})) > 0
        costvolume(:,:,i) = boxfilter(costimg,ceil(1.414*sigma_s));
    elseif sum(strcmpi(filter_type, {'isomed','isomod'})) > 0
        costvolume(:,:,i) = gaussfilter(costimg,sigma_s);
    elseif sum(strcmpi(filter_type, {'wmed','wmod'})) > 0
        costvolume(:,:,i) = guidedfilter(guidance,costimg,ceil(1.414*sigma_s),sigma_r/Irange,Irange);
    else
        error(errstr_filtertype);
    end
end

% get three points near minima
[Kmin, K0] = min(costvolume, [], 3);
Kplus = min(N,K0+1);
Kminus = max(1,K0-1);

% interpolation
K_quad = zeros(h,w);
for i = 1:h
    for j = 1:w
        pcost = costvolume(i,j,Kplus(i,j));
        zcost = Kmin(i,j);
        mcost = costvolume(i,j,Kminus(i,j));
        
        % parabola fitting
        K_quad(i,j)=K0(i,j)-((pcost-mcost)./(2*(pcost+mcost-2*zcost))); %Eq. 11
    end
end

OUT = min(max((K_quad-1)*Idelta + Imin, Imin), Imax);

% for uint8 input, convert it back to uint8
if is_uint8
    OUT = uint8(OUT);
end

