function imDst = gaussfilter(imSrc, sigma)

hsize = ceil(7*sigma);
if rem(hsize,2) == 0
    hsize = hsize + 1; %make the hsize be an even number
end
G = fspecial('gaussian',hsize,sigma);
imDst = imfilter(imSrc,G,'symmetric','same');

end

