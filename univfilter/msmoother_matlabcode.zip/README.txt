The Matlab code is attached with the following paper:

Linchao Bao and Qingxiong Yang, 
"Robust Piecewise-Constant Smoothing: M-Smoother Revisited", 
arXiv:1410.7580 [cs.CV], 2014.

Please type "help msmoother" in Matlab for the usage. 
For a simple example, please run the following script: 

% -----------------------------------
I = imread('noisesyn.png'); 
J = msmoother(I,'wmod'); % try med, isomed, mod, isomod, wmed, wmod
figure, imshow([I, J]); colormap jet;
% -----------------------------------

For more information, please visit our webpages (http://www.cs.cityu.edu.hk/~linchabao2/).

ACKNOWLEDGEMENT: The boxfilter and guidedfilter code are from Dr. Kaiming He's webpage 
    (http://research.microsoft.com/en-us/um/people/kahe/eccv10/guided-filter-code-v1.rar). 
    Thanks for sharing! 
    
    