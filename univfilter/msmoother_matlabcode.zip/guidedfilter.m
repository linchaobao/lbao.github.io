function q = guidedfilter(I, p, r, eps, Irange)
%   GUIDEDFILTER   O(1) time implementation of guided filter.
%
%   - guidance image: I (should be a gray-scale/single channel image)
%   - filtering input image: p (should be a gray-scale/single channel image)
%   - local window radius: r
%   - regularization parameter: eps
%
%   Please refer to the paper: 
%   Guided Image Filtering, by Kaiming He, Jian Sun, and Xiaoou Tang, in
%   ECCV 2010.
%
%   Code from Kaiming He with a little modification 
%   (http://research.microsoft.com/en-us/um/people/kahe/eccv10/). 

[hei, wid] = size(I);

%%%%%%%
% add by Linchao Bao, one more parameter indicating image intensity range
if ~exist('Irange', 'var')
    Irange = max(I(:))-min(I(:));
end
eps = eps * Irange * Irange;
%%%%%%%

N = boxfilter(ones(hei, wid), r); % the size of each local patch; N=(2r+1)^2 except for boundary pixels.

mean_I = boxfilter(I, r) ./ N;
mean_p = boxfilter(p, r) ./ N;
mean_Ip = boxfilter(I.*p, r) ./ N;
cov_Ip = mean_Ip - mean_I .* mean_p; % this is the covariance of (I, p) in each local patch.

mean_II = boxfilter(I.*I, r) ./ N;
var_I = mean_II - mean_I .* mean_I;

a = cov_Ip ./ (var_I + eps); % Eqn. (5) in the paper;
b = mean_p - a .* mean_I; % Eqn. (6) in the paper;

mean_a = boxfilter(a, r) ./ N;
mean_b = boxfilter(b, r) ./ N;

q = mean_a .* I + mean_b; % Eqn. (8) in the paper;
end