
% filtering with bilateral filter
I = imread('noisesyn.png'); 
J = UnivFilter(I,4,0.03,0.15,0.5,16); 
figure, imshow([I, J]); colormap jet;


% % filtering with guided filter
% I = imread('noisesyn.png'); 
% J = UnivFilter(I,5,0.03,0.1,0.5,16); 
% figure, imshow([I, J]); colormap jet;


% % filtering with Gaussian filter
% I = imread('noisesyn.png'); 
% J = UnivFilter(I,2,0.03,0,0.5,16); 
% figure, imshow([I, J]); colormap jet;


% % filtering with box filter
% I = imread('noisesyn.png'); 
% J = UnivFilter(I,1,0.03,0,0.5,16); 
% figure, imshow([I, J]); colormap jet;


% % filtering with median filter
% I = imread('noisesyn.png'); 
% J = UnivFilter(I,3,0.08,0,0.5,16); 
% figure, imshow([I, J]); colormap jet;

