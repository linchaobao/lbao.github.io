function [I] = BilateralFilter_Approx(img, sigma_s, sigma_r, texture, N)
%BILATERALFILTER_APPROX  Fast bilateral filter implemented by Linchao Bao. 
% 
%   Example
%   -------
%   I = imread('noisesyn.png');
%   J = BilateralFilter_Approx(I,0.03,0.15,I,32);
%   figure; imshow(uint8(J));
%
%   Any advice or bug report is welcome. Please kindly contact Linchao Bao 
%   by email (linchaobao@gmail.com). Thanks. 


if ~exist('texture', 'var')
    texture = img;
end
if ~exist('N', 'var')
    N = 32;
end

img = double(img);
texture = double(texture);

[h,w] = size(img);
Imin = double(min(texture(:)));
Imax = double(max(texture(:)));
Idelta = (Imax - Imin) / double(N-1);

if sigma_s < 1.0
    sigma_s = sigma_s * min(h,w);
end
if sigma_r < 1.0
    sigma_r = sigma_r * (Imax-Imin);
end

sp_filter = GenGaussKernel(ceil(10*sigma_s), sigma_s);
d = size(sp_filter);
r = floor(d(1) / 2);

% make a temp larger image, mirror it
img_ext = PaddingImgByMirrorEdge(img, r); %new size (h+2*r, w+2*r)
texture_ext = PaddingImgByMirrorEdge(texture, r);

% use FFT to calculate convolution for each bin
sp_kernel_ext = zeros(h + 2*r, w + 2*r);
sp_kernel_ext(1:d, 1:d) = sp_filter;
sp_kernel_fft = fft2(sp_kernel_ext);
I = zeros(h, w);
texture_rounded=round((texture-Imin)/Idelta)*Idelta+Imin; %quantization

for rg = Imin:Idelta:Imax
    rg_gs_coef = exp(-(abs(double(rg)-texture_ext).^2) / (2*sigma_r^2));
    rg_gs_img = rg_gs_coef .* img_ext;
    
    % use fft to compute convolution for img
    rg_gs_img_fft = fft2(rg_gs_img);
    rg_blf_fft = rg_gs_img_fft .* sp_kernel_fft;
    
    % use fft to compute convolution for coefficient
    rg_gs_coef_fft = fft2(rg_gs_coef);
    rg_coef_blf_fft = rg_gs_coef_fft .* sp_kernel_fft;
    
    % blf
    blf_rg = ifft2(rg_blf_fft) ./ ifft2(rg_coef_blf_fft);
    
    % trim off edges
    blf_rg = blf_rg(1+2*r:end, 1+2*r:end);
    
    % fill into output pixels
    pix_ind = find(double(texture_rounded) == rg);
    I(pix_ind) = blf_rg(pix_ind);
end


%% tool functions
function [T] = GenGaussKernel(size, sigma)
    size = ceil(size);
    if mod(size, 2) == 0
        size = size + 1;
    end
    distMat = zeros(size, size);
    centerIdx = ceil(size / 2);
    for i = 1:size
        for j = 1:size
            distMat(i,j) = sqrt(abs(i-centerIdx)^2 + abs(j-centerIdx)^2);
        end
    end
    T = exp(-distMat.^2 / (2 * sigma^2));
end

function [img_ext] = PaddingImgByMirrorEdge(img, r)
    [h,w] = size(img);
    img_ext = zeros(h+2*r,w+2*r);
    img_ext(r+1:h+r,r+1:w+r)=img;
    img_ext(1+r:h+r,1:r)=flipdim(img(1:h,2:r+1),2);
    img_ext(1+r:h+r,w+r+1:w+r+r)=flipdim(img(1:h,w-r:w-1),2); 
    img_ext(1:r,1:w+r+r)=flipdim(img_ext(r+2:r+r+1,1:w+r+r),1); 
    img_ext(h+r+1:h+r+r,1:w+r+r)=flipdim(img_ext(h+r-r:h+r-1,1:w+r+r),1); 
end

end


