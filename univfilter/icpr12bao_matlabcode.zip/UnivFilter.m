function [OUT]=UnivFilter(img,filter_type,sigma_s,sigma_r,alpha,N,guidance)
%UNIVFILTER An edge-preserving filtering method for images. 
%
%   UNIVFILTER can perform edge-preserving filtering for images by 
%   integrating existing filters (Gaussian filter, bilateral filter, 
%   guided filter, etc.) using alpha < 2.0. If the integrated filter is 
%   already an edge-preserving filter like bilateral filter, the edge-
%   preserving ability can be enhanced (with alpha < 2.0). If you find this
%   method useful, please cite our paper (a journal version is coming):
%
%   Linchao Bao, Yibing Song, Qingxiong Yang, and Narendra Ahuja, "An Edge-
%   preserving Filtering Framework for Visibility Restoration", ICPR 2012. 
%
%   Any advice or bug report is welcome. Please kindly contact Linchao Bao 
%   by email (linchaobao@gmail.com). Thanks. 
%
%   
%   Usage
%   -----
%   [OUT] = UNIVFILTER(img,filter_type,sigma_s,sigma_r,alpha,N,guidance)
%   PARAMETERS: 
%             img: input 1-channel image.
%             filter_type: a number indicating which filter to integrate:
%                                  1 for box filter,
%                                  2 for Gaussian filter,
%                                  3 for median filter,
%                                  4 for bilateral filter,
%                                  5 for guided filter. 
%             sigma_s: the (first) parameter for the chosen filter. For
%                      example, for Gaussian filter it is the sigma, and 
%                      for bilateral filter it is the sigma_spatial. Note 
%                      that it should be a real number in (0,1). The 
%                      default value is 0.05. 
%             sigma_r: the second parameter for the chosen filter. For
%                      example, for bilateral filter it is the sigma_range,
%                      and for guided filter it is the epsilon. It usually
%                      should be also a real number in (0,1). The default
%                      value is 0.1. 
%             alpha: the alpha value to control the edge-preserving
%                    ability. It should be a real number in (0,2). The
%                    smaller alpha, the stronger edge-preserving ability.
%                    Note that if it is too small (near 0), the result will
%                    not be stable. The suggested value is 0.5. 
%             N: the number of sampling intensity levels for
%                approximation. With larger N, the result will be more
%                accurate but the speed will be slower. Default value 32.
%                Try 8 or 16 for faster speed, and try 64 and 128 for more
%                accurate results (e.g., HDR images). 
%             guidance: the guidance image for joint bilateral filter or
%                       guided filter. Default is the original input image.
%
%
%   Example
%   -------
%   I = imread('noisesyn.png'); 
%   J = UnivFilter(I,4,0.03,0.15,0.5,16); 
%   figure, imshow([I, J]); colormap jet;


if ~exist('sigma_s', 'var')
    sigma_s = 0.05;
end
if ~exist('sigma_r', 'var')
    sigma_r = 0.1;
end
if ~exist('alpha', 'var')
    alpha = 0.5;
end
if ~exist('N', 'var')
    N = 32;
end
if ~exist('guidance', 'var')
    guidance = img;
end

[h,w,c] = size(img);
if c > 1
    img = rgb2gray(img);
end
if size(guidance,3) > 1
    guidance = rgb2gray(guidance);
end

img = double(img); 
guidance = double(guidance);

Imax = max(img(:));
Imin = min(img(:));
Irange = Imax - Imin;

sigma_s = ceil(sigma_s*min(h,w)); 
sigma_r = sigma_r*Irange; 

DF = zeros(h,w,N);
Idelta = Irange / (N-1);
Ik = Imin:Idelta:Imax;

% prepare a Gaussian kernel for Gaussian filtering
hsize = ceil(10*sigma_s);
if rem(hsize,2) == 0
    hsize = hsize + 1; %make the hsize be an even number
end
G = fspecial('gaussian',hsize,sigma_s);

% begin filtering
for i = 1:N
    D = abs(Ik(i)-img) .^ alpha;
    
    % filtering D
    if filter_type == 1
        DF(:,:,i) = boxfilter(D,sigma_s);
    elseif filter_type == 2
        DF(:,:,i) = imfilter(D,G,'symmetric','same');
    elseif filter_type == 3
        DF(:,:,i) = medfilt2(D,[sigma_s,sigma_s],'symmetric');
    elseif filter_type == 4
        DF(:,:,i) = BilateralFilter_Approx(D,sigma_s,sigma_r,guidance);
    elseif filter_type == 5
        DF(:,:,i) = guidedfilter(guidance,D,sigma_s,sigma_r/Irange,Irange);
    else
        DF(:,:,i) = D; %no filtering
    end
end

% get three points near minima
[Kmin, K0] = min(DF, [], 3);
Kplus = min(N,K0+1);
Kminus = max(1,K0-1);

% interpolation
K_quad = zeros(h,w);
for i = 1:h
    for j = 1:w
        pcost = DF(i,j,Kplus(i,j));
        zcost = Kmin(i,j);
        mcost = DF(i,j,Kminus(i,j));
        
        %quadratic interpolation
        K_quad(i,j)=K0(i,j)-((pcost-mcost)./(2*(pcost+mcost-2*zcost)));
    end
end

OUT = min(max((K_quad-1)*Idelta + Imin, Imin), Imax);

% for 256-level grayscale image, convert it into uint8 type
if abs(ceil(Irange) - Irange) < eps
    OUT = uint8(OUT);
end

