The Matlab code is attached with the following paper:


Linchao Bao, Yibing Song, Qingxiong Yang, and Narendra Ahuja, "An Edge-preserving Filtering Framework for Visibility Restoration", ICPR 2012.


Please type "help UnivFilter" in Matlab for more information. For a simple example, just use the following script to see the filtering behavior of the filtering method: 

% -----------------------------------
I = imread('noisesyn.png'); 
J = UnivFilter(I,4,0.03,0.15,0.5,16); 
figure, imshow([I, J]); colormap jet;
% -----------------------------------


For more information, please visit our webpages here (http://www.cs.cityu.edu.hk/~qiyang/) and here (http://www.cs.cityu.edu.hk/~linchabao2/).


ACKNOWLEDGEMENT: The boxfilter and guidedfilter code are taken from Kaiming He's webpage (http://research.microsoft.com/en-us/um/people/kahe/eccv10/guided-filter-code-v1.rar). Thanks for sharing! 

