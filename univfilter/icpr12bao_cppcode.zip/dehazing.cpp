/*
 * Image dehazing algorithm. 
 * See paper: Linchao Bao, Yibing Song, Qingxiong Yang, and Narendra Ahuja, 
              "An Edge-Preserving Filtering Framework for Visibility Restoration.", 
              ICPR 2012.
 * Code by Linchao Bao. For academic use only. 
 */
#include "bao_basic_lib.h"
#include "bao_univfilter.h"


// Filtering-based dehazing algorithm, assuming image has already been white-balanced
void image_dehazing(unsigned char*** dest, unsigned char*** image, int h, int w, double sig_s, double sig_r)
{
    // get min color component, Eq (7) in paper
    double** D = bao_alloc<double>(h, w);
    for (int i=0; i<h; i++) for (int j=0; j<w; j++)
    {
        D[i][j] = __min(image[i][j][0],__min(image[i][j][1],image[i][j][2]));
    }

    // filter W to get B, Eq (8) and (9) combined (proposed filtering framework)
    double** B = bao_alloc<double>(h, w);
    bao_univfilter obj_uf;
    obj_uf.init(h,w);
    obj_uf.filter(B,D,image,sig_s,sig_r);

    // calculate t = 1 - min(eps*B,D), Eq (10) in paper
    double range = 255.0;
    double inv_range = 1.0 / 255.0;
    double eps = 0.95; 
    double** T = bao_alloc<double>(h, w);
    for (int i=0; i<h; i++) for (int j=0; j<w; j++)
    {
        T[i][j] = 1.0 - __min(eps*B[i][j], D[i][j])*inv_range;
        if (T[i][j] < 0) T[i][j] = 0.0;
    }
    
    // restoration dest = 1-(1-I)/T, Eq (11) in paper
    for (int i=0; i<h; i++) for (int j=0; j<w; j++) for (int k=0; k<3; k++)
    {
        double pixval = 1.0 - ((1.0 - double(image[i][j][k])*inv_range) / T[i][j]);
        dest[i][j][k] = (unsigned char)(__min(range, __max(0,pixval*range)));
    }
    
    // release memory
    bao_free(D);
    bao_free(B);
    bao_free(T);
}


// Tool function for final gamma correction, assuming all image values are in [0,255]
void gamma_correction(unsigned char*** dest, unsigned char*** src, unsigned char*** orig, int h, int w) 
{
    // calculate index
    double** M_orig = bao_alloc<double>(h/3, w);
    double** M_src = bao_alloc<double>(h/3, w);
    double temp_pix_orig = 0.0;
    double temp_pix_src = 0.0;
    double mean_orig = 0.0;
    double mean_src = 0.0;
    double eps = 0.5 / 255.0;
    int st_i = 2*h/3+1;
    for (int i=st_i; i<h; i++)
    {
        for (int j=0; j<w; j++)
        {
            temp_pix_orig = 0.0;
            temp_pix_src = 0.0;
            for (int k=0; k<3; k++)
            {
                temp_pix_orig += (orig[i][j][k] / 255.0);
                temp_pix_src += (src[i][j][k] / 255.0);
            }
            temp_pix_orig /= 3;
            temp_pix_src /= 3;

            M_orig[i-st_i][j] = log(temp_pix_orig + eps);
            M_src[i-st_i][j] = log(temp_pix_src + eps);
            mean_orig += M_orig[i-st_i][j];
            mean_src += M_src[i-st_i][j];
        }
    }
    mean_orig /= ((h/3)*w);
    mean_src /= ((h/3)*w);

    double std_orig = 0.0;
    double std_src = 0.0;
    for (int i=0; i<h/3; i++)
    {
        for (int j=0; j<w; j++)
        {
            std_orig += pow(M_orig[i][j] - mean_orig, 2);
            std_src += pow(M_src[i][j] - mean_src, 2);
        }
    }
    std_orig = sqrt(std_orig / ((h/3)*w));
    std_src = sqrt(std_src / ((h/3)*w));

    // mapping U = R .^ (1.3*di/dr) .* exp(ai - ar*1.3*di/dr)
    double*** U = bao_alloc<double>(h, w, 3);
    double idx = 1.3 * std_orig / std_src;
    double max_u = 0.0;
    for (int i=0; i<h; i++)
    {
        for (int j=0; j<w; j++)
        {
            for (int k=0; k<3; k++)
            {
                U[i][j][k] = pow(src[i][j][k]/255.0, idx) * exp(mean_orig - mean_src*idx);
                if (U[i][j][k] > max_u)
                    max_u = U[i][j][k];
            }
        }
    }

    // final conversion
    double pixval = 0.0;
    for (int i=0; i<h; i++)
    {
        for (int j=0; j<w; j++)
        {
            for (int k=0; k<3; k++)
            {
                pixval = (U[i][j][k] / (1.0 + (1.0 - 1.0/max_u)*U[i][j][k]));
                dest[i][j][k] = (pixval * 255);
            }
        }
    }

    bao_free(M_orig); 
    bao_free(M_src); 
    bao_free(U); 
}




