The dehazing (haze removal) code is an implementation of the following paper (note that bilateral filter is replaced with a guided filter in this implementation, thus the results may be slightly different):

@inproceedings{bao2012edge,
  title={An edge-preserving filtering framework for visibility restoration},
  author={Bao, Linchao and Song, Yibing and Yang, Qingxiong and Ahuja, Narendra},
  booktitle={21st International Conference on Pattern Recognition (ICPR 2012)},
  pages={384--387},
  year={2012},
  organization={IEEE}
}

It has been successfully compiled in Visual Studio 2008 (under 64-bit Windows 7). Please contact Linchao Bao (linchaobao at gmail dot com) to report bugs. 

Note that the code is only for academic use, please do not distribute it for other purposes. 

