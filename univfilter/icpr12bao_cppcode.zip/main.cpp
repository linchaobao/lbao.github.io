#include "bao_basic_lib.h"
#include "dehazing.h"


int main()
{
    char* file_name = "canon3.ppm";
    char* file_output_name = "dehazing_result.ppm";
    int h,w;
    bool is_img_valid = qx_imagesize(file_name,h,w);
    if (!is_img_valid)
        return -1; 

    unsigned char*** input_img = bao_alloc<unsigned char>(h,w,3);
    unsigned char*** output_img = bao_alloc<unsigned char>(h,w,3);
    qx_loadimage(file_name,input_img[0][0],h,w);

    // parameter settings
    double sig_s = 0.05*__min(h,w);
    double sig_r = 0.03; //for strong smoothing, tune this parameter larger (e.g., 0.1, 0.2)

    // dehazing
    bao_timer_cpu timer;
    timer.start();
    image_dehazing(output_img, input_img, h, w, sig_s, sig_r);
    timer.time_display("dehazing");

    // final gamma correction
    gamma_correction(output_img, output_img, input_img, h, w);

    // save image
    qx_saveimage(file_output_name,output_img[0][0],h,w,3);
    
    bao_free(input_img);
    bao_free(output_img);
    return 0;
}

