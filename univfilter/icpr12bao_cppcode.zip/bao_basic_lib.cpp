#include "bao_basic_lib.h"


//////////////////////////////////////////////////////////////////////////
// CPU timer
#ifdef _WIN32
#include <windows.h>
#else
#include <sys/time.h>
#endif

void bao_timer_cpu::start()
{
#ifdef _WIN32
    LARGE_INTEGER li;
    if(!QueryPerformanceFrequency(&li)) 
    {
        printf("QueryPerformanceFrequency failed!\n");
    }
    m_pc_frequency = double(li.QuadPart); ///1000.0;
    QueryPerformanceCounter(&li);
    m_counter_start = li.QuadPart;
#else
    gettimeofday(&timerStart, NULL);
#endif
}

double bao_timer_cpu::stop()
{
#ifdef _WIN32
    LARGE_INTEGER li;
    QueryPerformanceCounter(&li);
    return double(li.QuadPart-m_counter_start)/m_pc_frequency;
#else
    struct timeval timerStop, timerElapsed;
    gettimeofday(&timerStop, NULL);
    timersub(&timerStop, &timerStart, &timerElapsed);
    return timerElapsed.tv_sec*1000.0+timerElapsed.tv_usec/1000.0;
#endif
}

void bao_timer_cpu::time_display(char *disp,int nr_frame)
{ 
    printf("Running time (%s) is: %5.5f Seconds.\n",disp,stop()/nr_frame);
}

void bao_timer_cpu::fps_display(char *disp,int nr_frame)
{ 
    printf("Running time (%s) is: %5.5f frame per second.\n",disp,(double)nr_frame/stop());
}


//////////////////////////////////////////////////////////////////////////
// Other tools
BAO_FLOAT bao_inv_3x3(BAO_FLOAT h_inv[9],BAO_FLOAT h_in[9],BAO_FLOAT threshold)
{
    BAO_FLOAT det;
    BAO_FLOAT h5h7, h4h8, h3h8,h5h6,h4h6,h3h7;
    BAO_FLOAT h1h8, h2h7, h0h8, h2h6, h0h7, h1h6, h1h5, h2h4, h0h5, h2h3, h0h4, h1h3;
    h4h8= h_in[4]*h_in[8]; h5h7=h_in[5]*h_in[7]; h3h8= h_in[3]*h_in[8]; 
    h5h6= h_in[5]*h_in[6]; h3h7= h_in[3]*h_in[7]; h4h6= h_in[4]*h_in[6]; 
    det= h_in[0]*(h4h8-h5h7)-h_in[1]*(h3h8-h5h6)+h_in[2]*(h3h7-h4h6);
    if (abs(det)<threshold) 
    {
        printf("[det<%e] ",threshold);
        memset(h_inv,0,sizeof(BAO_FLOAT)*9);
    }
    else
    {
        h1h8= h_in[1]*h_in[8];
        h2h7= h_in[2]*h_in[7];
        h0h8= h_in[0]*h_in[8]; 
        h2h6= h_in[2]*h_in[6]; 
        h0h7= h_in[0]*h_in[7];
        h1h6= h_in[1]*h_in[6]; 
        h1h5= h_in[1]*h_in[5];
        h2h4= h_in[2]*h_in[4];
        h0h5= h_in[0]*h_in[5];
        h2h3= h_in[2]*h_in[3];
        h0h4= h_in[0]*h_in[4];
        h1h3= h_in[1]*h_in[3];
        //inv_det= 1.0/det;
        //h_inv[0]=  inv_det*(h4h8-h5h7);
        //h_inv[3]= -inv_det*(h3h8-h5h6);
        //h_inv[6]=  inv_det*(h3h7-h4h6);
        //h_inv[1]= -inv_det*(h1h8-h2h7);
        //h_inv[4]=  inv_det*(h0h8-h2h6);
        //h_inv[7]= -inv_det*(h0h7-h1h6);
        //h_inv[2]=  inv_det*(h1h5-h2h4);
        //h_inv[5]= -inv_det*(h0h5-h2h3);
        //h_inv[8]=  inv_det*(h0h4-h1h3);
        h_inv[0]=  (h4h8-h5h7)/det;
        h_inv[3]= -(h3h8-h5h6)/det;
        h_inv[6]=  (h3h7-h4h6)/det;
        h_inv[1]= -(h1h8-h2h7)/det;
        h_inv[4]=  (h0h8-h2h6)/det;
        h_inv[7]= -(h0h7-h1h6)/det;
        h_inv[2]=  (h1h5-h2h4)/det;
        h_inv[5]= -(h0h5-h2h3)/det;
        h_inv[8]=  (h0h4-h1h3)/det;
    }
    return(det);
    //for (int i=0; i<9; i++) { cout<<h_inv[i]<<" "; } cout<<endl;
}


//////////////////////////////////////////////////////////////////////////
// Read, write PPM, PGM file. 


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <memory.h>

#include <algorithm> //for min,max
using namespace std;


#define QX_DEF_IS_PPM 1
#define QX_DEF_IS_PGM 0
#define LEN_MAX	256


int qx_imagesize(char* filename, int &h, int &w)
{
    FILE * file_in; int nr_channel;
    char line[LEN_MAX];
    int	p_idx;	
    unsigned char *image=NULL;
    //file_in=fopen(filename,"rb");
    fopen_s(&file_in,filename,"rb");
    if(!file_in)
    {
        printf("Please check input filename: %s\n",filename);
        getchar();
        exit(0);
    }
    if(fgetc(file_in)=='P') 
        //fscanf(file_in,"%d\n",&p_idx);
        fscanf_s(file_in,"%d\n",&p_idx);
    else
    { 
        printf("Bad	header in ppm file.\n");
        getchar();
        exit(1);
    }
    while(fgets(line,LEN_MAX,file_in)!=NULL)
    {
        if(line[0]=='#') continue;
        else
        {
            sscanf_s(line, "%d %d\n",	&w,	&h);
            if(p_idx==9) 
            {
                fscanf_s(file_in,"%d\n",&nr_channel);
            }
            else if(p_idx==5||p_idx==2||p_idx==7) nr_channel=1;
            else if(p_idx==6||p_idx==3||p_idx==8) nr_channel=3;
            break;
        }
    }
    fclose(file_in);
    return(nr_channel);
}

int qx_loadimage(char* filename,unsigned char *image,int h,int w,int *nr_channel)
{
    FILE * file_in; int nrc;
    char line[LEN_MAX];
    int	i; int imax,hc,wc;	
    unsigned char *image_=image;
    fopen_s(&file_in,filename,"rb");
    if(!file_in)
    {
        printf("Please check input filename: %s\n",filename);
        exit(0);
    }
    if(fgetc(file_in)=='P') 
        fscanf_s(file_in,"%d\n",&i);
    else
    {
        printf("Bad	header in ppm file.\n");
        exit(1);
    }
    while(fgets(line,LEN_MAX,file_in)!=NULL)
    {
        if(line[0]=='#') continue;
        else
        {	
            sscanf_s(line, "%d %d\n",&wc,&hc);
            break;
        }
    }
    char str_tmp[100];
    switch (i)
    {
    case 5:
        fgets(str_tmp,100,file_in);
        imax=atoi(str_tmp);
        if(nr_channel!=NULL) (*nr_channel)=1;
        memset(image,0,sizeof(unsigned char)*h*w);
        fread(image,sizeof(unsigned char),h*w,file_in);
        break;
    case 6:
        fgets(str_tmp,100,file_in);
        imax=atoi(str_tmp);
        if(nr_channel!=NULL) (*nr_channel)=3;
        memset(image,0,sizeof(unsigned char)*h*w*3);
        fread(image,sizeof(unsigned char),h*w*3,file_in);
        break;
    case 2:
        fgets(str_tmp,100,file_in);
        imax=atoi(str_tmp);
        for(int y=0;y<h;y++) for(int x=0;x<w;x++)
        {
            //if(fscanf_s(file_in,"%d",&imax)!=1){printf("error in reading file.\n");getchar();exit(0);}
            fscanf_s(file_in,"%d",&imax);
            *image_++=imax;
        }
        break;
    case 3:
        fgets(str_tmp,100,file_in);
        imax=atoi(str_tmp);
        int cr,cg,cb;
        for(int y=0;y<h;y++) for(int x=0;x<w;x++)
        {
            //if(fscanf_s(file_in,"%d%d%d",&cr,&cg,&cb)!=3){printf("error in reading file.\n");getchar();exit(0);}
            fscanf_s(file_in,"%d%d%d",&cr,&cg,&cb);
            *image_++=cr; *image_++=cg; *image_++=cb; 
        }
        break;
    case 9:
        fgets(str_tmp,100,file_in);
        nrc=atoi(str_tmp);
        fscanf_s(file_in,"%d\n",&nrc);
        if(nr_channel!=NULL) (*nr_channel)=nrc;
        fgets(str_tmp,100,file_in);
        imax=atoi(str_tmp);
        fread(image,sizeof(unsigned char),h*w*nrc,file_in);
        break;
    default:
        printf("Can not open image [%s]!!\n",filename);
        break;					
    }
    fclose(file_in);
    return (0);
}

void qx_saveimage(char* filename,unsigned char *image,int h,int w,int channel)
{	
    FILE* file_out; unsigned char maxx=255;
    fopen_s(&file_out,filename,"wb");
    if(channel==1) fprintf(file_out,"P5\n%d %d\n%d\n",w,h,maxx);
    //else if(channel==3) fprintf(file_out,"P6\n%d %d\n%d\n",w,h,maxx);
    else if(channel==3) fprintf(file_out,"P6\n%d %d\n%d\n",w,h,maxx);
    else fprintf(file_out,"P9\n%d %d\n%d\n%d\n",w,h,channel,maxx);
    fwrite(image,sizeof(unsigned char),h*w*channel,file_out);

    fclose(file_out);
}

