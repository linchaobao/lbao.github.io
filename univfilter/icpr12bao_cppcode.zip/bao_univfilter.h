/*
 * Layered edge-preserving filtering (see the following paper, use guided filter instead of bilateral filter). 
 * See paper: Linchao Bao, Yibing Song, Qingxiong Yang, and Narendra Ahuja, 
              "An Edge-Preserving Filtering Framework for Visibility Restoration.", 
              ICPR 2012.
 * Code by Linchao Bao. For academic use only. 
 */
#ifndef _BAO_UNIVFILTER_H_
#define _BAO_UNIVFILTER_H_

#include "bao_basic_lib.h"

class bao_univfilter
{
public:
    bao_univfilter():m_h(0),m_w(0),m_nr_layer(0),m_temp_d1(NULL),m_temp_d2(NULL),m_cost_f(NULL),m_gray_img(NULL){}
    ~bao_univfilter(){ _clean(); }
    void init(int h,int w,int nr_layer=16);
    void filter(double**image_filtered,double**image,unsigned char***texture,double sig_s,double sig_r);

private:
    void _clean();

private:
    int m_h;
    int m_w;
    int m_nr_layer;
    bao_guided_filter<double,unsigned char> m_gf;
    double** m_temp_d1;
    double** m_temp_d2;
    float*** m_cost_f;
    unsigned char** m_gray_img;
};



#endif