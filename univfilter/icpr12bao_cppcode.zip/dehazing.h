/*
 * Image dehazing algorithm. 
 * See paper: Linchao Bao, Yibing Song, Qingxiong Yang, and Narendra Ahuja, 
              "An Edge-Preserving Filtering Framework for Visibility Restoration.", 
              ICPR 2012.
 * Code by Linchao Bao. For academic use only. 
 */
#ifndef _BAO_DEHAZING_H_
#define _BAO_DEHAZING_H_


void image_dehazing(unsigned char*** dest, unsigned char*** image, int h, int w, double sig_s, double sig_r);
void gamma_correction(unsigned char*** dest, unsigned char*** src, unsigned char*** orig, int h, int w);


#endif
