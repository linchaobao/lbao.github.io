/*
 * Layered edge-preserving filtering (see the following paper, use guided filter instead of bilateral filter). 
 * See paper: Linchao Bao, Yibing Song, Qingxiong Yang, and Narendra Ahuja, 
              "An Edge-Preserving Filtering Framework for Visibility Restoration.", 
              ICPR 2012.
 * Code by Linchao Bao. For academic use only. 
 */
#include "bao_univfilter.h"


void bao_univfilter::init(int h,int w,int nr_layer)
{
    m_h = h;
    m_w = w;
    m_nr_layer = nr_layer;
    m_gf.init(m_h,m_w,true);
    m_temp_d1 = bao_alloc<double>(m_h,m_w);
    m_temp_d2 = bao_alloc<double>(m_h,m_w);
    m_cost_f = bao_alloc<float>(m_h,m_w,nr_layer);
    m_gray_img = bao_alloc<unsigned char>(m_h,m_w);
}

void bao_univfilter::_clean()
{
    bao_free(m_temp_d1);
    bao_free(m_temp_d2);
    bao_free(m_cost_f);
    bao_free(m_gray_img);
}


void bao_univfilter::filter(double**image_filtered,double**image,unsigned char***texture,double sig_s,double sig_r)
{
    double val_min,val_max;
    bao_vec_minmax(val_min,val_max,image[0],m_h*m_w);
    bao_rgb2gray(m_gray_img,texture,m_h,m_w); //currently only use grayscale image as filtering guidance

    float delta_grayscale=(val_max-val_min)/(m_nr_layer-1);
    for(int d=0;d<m_nr_layer;d++)
    {
        float dvalue=delta_grayscale*d+val_min;
        for(int y=0;y<m_h;y++)
        {
            for(int x=0;x<m_w;x++)
            {
                if(image[y][x]>0) m_temp_d1[y][x]=min(abs(dvalue-image[y][x]),0.1*255);
                else m_temp_d1[y][x]=0;
            }
        }
        m_gf.filter(m_temp_d2,m_temp_d1,m_gray_img,sig_s,sig_r);
        for(int y=0;y<m_h;y++)
        {
            for(int x=0;x<m_w;x++)
            {
                m_cost_f[y][x][d]=m_temp_d2[y][x];
            }
        }
    }

    int dmin;
    double mincost;
    double dx;
    double v0,v1,v2;
    for(int y=0;y<m_h;y++) for(int x=0;x<m_w;x++) 
    {
        mincost = m_cost_f[y][x][0];
        dmin = 0;
        for(int d=1;d<m_nr_layer;d++)
        {
            if (m_cost_f[y][x][d]<mincost)
            {
                mincost = m_cost_f[y][x][d];
                dmin = d;
            }
        }

        if(dmin==0||dmin==m_nr_layer-1) dx=0;
        else 
        {
            v0=m_cost_f[y][x][dmin];
            v1=m_cost_f[y][x][dmin-1];
            v2=m_cost_f[y][x][dmin+1];
            dx=(v2+v1-v0-v0==0)?0:0.5f*(v2-v1)/(v2+v1-v0-v0);
        }

        image_filtered[y][x]=(dmin-dx)*delta_grayscale+val_min;
    }
}



