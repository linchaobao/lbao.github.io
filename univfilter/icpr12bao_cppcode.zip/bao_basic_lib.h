/*
 * Basic tools. 
 * Code by Qingxiong Yang and Linchao Bao. For academic use only. 
 */
#ifndef _BAO_BASIC_LIB_H
#define _BAO_BASIC_LIB_H


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <memory.h>
//#include <type_traits> //for template, see if T is a specific type: (std::is_integral<unsigned char>::value)

#include <iostream>
using std::cout;
using std::endl;
using std::cin;

#include <algorithm>
using std::max;
using std::min;

#include <limits> //for type traits
using std::numeric_limits;


typedef double BAO_FLOAT;
#define BAO_ZERO  1e-16

#define NOMINMAX  

#define BAO_UCHAR_MAX              255

//////////////////////////////////////////////////////////////////////////
// Memory allocate and free
#define BAO_MEM_PADDING  0  

template<typename T>
inline T* bao_alloc(int n)
{
    T* p;
    p=(T*) malloc(sizeof(T)*(n+BAO_MEM_PADDING));
    if (p==NULL) {printf("bao_alloc_1(): memory allocation (%d MB) failed.\n",sizeof(T)*(n+BAO_MEM_PADDING)/(1024*1024)); getchar(); exit(0); }
    return (p);
}

template<typename T>
inline void bao_free(T* &p)
{
    if (p!=NULL)
    {
        free(p);
        p=NULL;
    }
}

template<typename T>
inline T** bao_alloc(int r,int c)
{
    T *a,**p;
    a=(T*) malloc(sizeof(T)*(r*c+BAO_MEM_PADDING));
    if(a==NULL) {printf("bao_alloc_2(): memory allocation (%d MB) failed.\n",sizeof(T)*(r*c+BAO_MEM_PADDING)/(1024*1024)); getchar(); exit(0); }
    p=(T**) malloc(sizeof(T*)*r);
    for(int i=0;i<r;i++) p[i]= &a[i*c];
    return(p);
}

template<typename T>
inline void bao_free(T** &p)
{
    if(p!=NULL)
    {
        free(p[0]);
        free(p);
        p=NULL;
    }
}

template<typename T>
inline T*** bao_alloc(int n,int r,int c) //NOTE: if parameters are (r,c,n), it is also OK
{
    T *a,**p,***pp;
    int rc=r*c;
    int i,j;
    a=(T*) malloc(sizeof(T)*(n*rc+BAO_MEM_PADDING));
    if(a==NULL) {printf("bao_alloc_3(): memory allocation (%d MB) failed.\n",sizeof(T)*(n*rc+BAO_MEM_PADDING)/(1024*1024)); getchar(); exit(0); }
    p=(T**) malloc(sizeof(T*)*n*r);
    pp=(T***) malloc(sizeof(T**)*n);
    for(i=0;i<n;i++) 
        for(j=0;j<r;j++) 
            p[i*r+j]=&a[i*rc+j*c];
    for(i=0;i<n;i++) 
        pp[i]=&p[i*r];
    return(pp);
}

template<typename T>
inline void bao_free(T*** &p)
{
    if(p!=NULL)
    {
        free(p[0][0]);
        free(p[0]);
        free(p);
        p=NULL;
    }
}


//////////////////////////////////////////////////////////////////////////
// CPU timer
#ifndef _WIN32
#include <sys/time.h>
#endif

class bao_timer_cpu
{
public: 
    void start(); 
    double stop(); 
    void time_display(char* disp="", int nr_frame=1); 
    void fps_display(char* disp="", int nr_frame=1); 
private: 
#ifdef _WIN32
    double m_pc_frequency; 
    __int64 m_counter_start;
#else
    struct timeval m_counter_start;
#endif
}; 


//////////////////////////////////////////////////////////////////////////
// Other tools
template<typename T1, typename T2>
inline T1 bao_type_cast(T2 val)
{
    BAO_FLOAT max_val = BAO_FLOAT(numeric_limits<T1>::max());
    BAO_FLOAT min_val = BAO_FLOAT(numeric_limits<T1>::min()); //NOTE: for float type, it is the minimum positive number!
    if (min_val>0) min_val = -max_val;
    return (T1)__max(min_val, __min(max_val, val));
}

template<typename T1, typename T2>
inline void bao_copy(T1* img_out, T2* img_in, int len)
{
    if (sizeof(T1) < sizeof(T2)) //truncation
    {
        for (int i=0;i<len;i++) img_out[i]=bao_type_cast<T1>(img_in[i]);
    }
    else
    {
        for (int i=0;i<len;i++) img_out[i]=T1(img_in[i]);
    }
}

template<typename T1, typename T2>
inline void bao_copy(T1** img_out, T2** img_in, int h, int w)
{
    if (sizeof(T1) < sizeof(T2)) //truncation
    {
        for (int i=0;i<h;i++) for(int j=0;j<w;j++) 
            img_out[i][j]=bao_type_cast<T1>(img_in[i][j]);
    }
    else
    {
        for (int i=0;i<h;i++) for(int j=0;j<w;j++) img_out[i][j]=T1(img_in[i][j]);
    }
}

template<typename T1, typename T2>
inline void bao_copy(T1*** img_out, T2*** img_in, int h, int w, int d=3)
{
    if (sizeof(T1) < sizeof(T2)) //truncation
    {
        for (int i=0;i<h;i++) for(int j=0;j<w;j++) for (int k=0;k<d;k++)
            img_out[i][j][k]=bao_type_cast<T1>(img_in[i][j][k]);
    }
    else
    {
        for (int i=0;i<h;i++) for(int j=0;j<w;j++) for (int k=0;k<d;k++) img_out[i][j][k]=T1(img_in[i][j][k]);
    }
}

template<typename T>
inline void bao_copy(T* img_out, T* img_in, int len){memcpy(img_out,img_in,sizeof(T)*len);}

template<typename T>
inline void bao_copy(T** img_out, T** img_in, int h, int w){memcpy(img_out[0],img_in[0],sizeof(T)*h*w);}

template<typename T>
inline void bao_copy(T*** img_out, T*** img_in, int h, int w, int d=3){memcpy(img_out[0][0],img_in[0][0],sizeof(T)*h*w*d);}

template<typename T>
inline void bao_memset(T** img_in, int h, int w){memset(img_in[0],0,sizeof(T)*h*w);}

template<typename T>
inline void bao_memset(T*** img_in, int h, int w, int d=3){memset(img_in[0][0],0,sizeof(T)*h*w*d);}

template<typename T>
inline T bao_dist_rgb_max(T* a, T* b) {T x,y,z; x=abs(a[0]-b[0]); y=abs(a[1]-b[1]); z=abs(a[2]-b[2]); return(max(max(x,y),z));}

template<typename T1, typename T2>
inline void bao_vec_dot_product(T1* out, T2* a, T2* b, int len){for(int i=0;i<len;i++)*out++=T1(*a++)*T1(*b++);}

template<typename T>
inline void bao_vec_minmax(T& min_val, T& max_val, T* vec, int len)
{
    max_val = vec[0];
    min_val = vec[0];
    for(int i=1; i<len; i++)
    {
        T cur_val = vec[i];
        if (cur_val>max_val) max_val = cur_val;
        if (cur_val<min_val) min_val = cur_val;
    }
}

template<typename T1, typename T2>
inline void bao_vec_rescale(T1* img_out, T2* img_in, int len, T1 new_max_val=1, T1 new_min_val=0, T2 ori_max_val=0, T2 ori_min_val=0)
{
    if (ori_max_val==ori_min_val) bao_vec_minmax(ori_min_val,ori_max_val,img_in,len);
    BAO_FLOAT ori_range_val = BAO_FLOAT(ori_max_val - ori_min_val);
    T1 new_range_val = new_max_val - new_min_val;
    BAO_FLOAT factor = new_range_val/ori_range_val;
    for(int i=0; i<len; i++)
    {
        img_out[i] = bao_type_cast<T1>((img_in[i]-(BAO_FLOAT)ori_min_val)*factor + new_min_val);
    }
}

template<typename T2>
inline void bao_vec_rescale(BAO_FLOAT* img_out, T2* img_in, int len, BAO_FLOAT new_max_val=1, BAO_FLOAT new_min_val=0, T2 ori_max_val=0, T2 ori_min_val=0)
{
    if (ori_max_val==ori_min_val) bao_vec_minmax(ori_min_val,ori_max_val,img_in,len);
    BAO_FLOAT ori_range_val = BAO_FLOAT(ori_max_val - ori_min_val);
    BAO_FLOAT new_range_val = new_max_val - new_min_val;
    BAO_FLOAT factor = new_range_val/ori_range_val;
    for(int i=0; i<len; i++)
    {
        img_out[i] = (BAO_FLOAT)((img_in[i]-(BAO_FLOAT)ori_min_val)*factor + new_min_val);
    }
}

template<typename T1, typename T2>
inline void bao_rgb2gray(T1** img_out, T2*** img_in, int h, int w)
{
    for (int i=0;i<h;i++) for(int j=0;j<w;j++) img_out[i][j]=bao_type_cast<T1>(img_in[i][j][0]*0.299+img_in[i][j][1]*0.587+img_in[i][j][2]*0.114);
}

template<typename T>
inline T bao_rgb2gray_pixel(T*pixval)
{
    return bao_type_cast<T>(pixval[0]*0.299+pixval[1]*0.587+pixval[2]*0.114);
}


template<typename T1, typename T2>
double bao_psnr(T1 **a,T2 **b,int h,int w)
{
    T1 *pa;
    T2 *pb; 
    double ssn=0;
    pa=a[0];
    pb=b[0];
    for(int y=0;y<h;y++)
    {
        for(int x=0;x<w;x++)
        {
            double ab=double((*pa++)-(*pb++))/255;
            ssn+=ab*ab;
        }
    }
    if(ssn<BAO_FLOAT_THRESH_ZERO) return 999.0;
    ssn=log(double(h*w)/ssn)*10.0/log(10.0);
    return (ssn);
}


BAO_FLOAT bao_inv_3x3(BAO_FLOAT out[9],BAO_FLOAT in[9],BAO_FLOAT threshold=BAO_ZERO);

inline int bao_round(BAO_FLOAT in_x){if(in_x<0) return (int)(in_x-0.5); else return (int)(in_x+0.5);} //because VC does not have a round()

template<typename T1, typename T2>
inline BAO_FLOAT bao_div(T1 x,T2 y){return (x/BAO_FLOAT(y+BAO_FLT_RELATIVE_ACCURACY));}



//////////////////////////////////////////////////////////////////////////
// Box filtering
template<typename T>
void bao_box_filtering(T**img_out,T**img_in,T**img_temp,BAO_FLOAT*temp_1w,int radius,int h,int w)
{
    if (radius*2 + 1 > min(h,w)) return; //too small radius

    /*horizontal filtering*/
    T* in = img_in[0];
    T* out = img_temp[0];
    BAO_FLOAT scale=1.0/(2*radius+1);
    BAO_FLOAT t;
    for (int y = 0; y < h; y++) {
        // do left edge
        t = in[y*w] * radius;
        for (int x = 0; x < radius+1; x++) {
            t += in[y*w+x];
        }
        out[y*w] = T(t * scale);
        for(int x = 1; x < radius+1; x++) {
            int c = y*w+x;
            t += in[c+radius];
            t -= in[y*w];
            out[c] = T(t * scale); //NOTE: for integer types, the conversion may possibly cause 0.5 lost!
        }
        // main loop
        for(int x = radius+1; x < w-radius; x++) {
            int c = y*w+x;
            t += in[c+radius];
            t -= in[c-radius-1];
            out[c] = T(t * scale); //NOTE: for integer types, the conversion may possibly cause 0.5 lost!
        }
        // do right edge
        for (int x = w-radius; x < w; x++) {
            int c = y*w+x;
            t += in[(y*w)+w-1];
            t -= in[c-radius-1];
            out[c] = T(t * scale); //NOTE: for integer types, the conversion may possibly cause 0.5 lost!
        }
    }

    /*vertical filtering*/ //TIPS: row by row memory access is faster, thus temp_1w is used!
    in = img_temp[0];
    out = img_out[0];
    scale = 1.0/(2*radius+1);
    for(int x=0;x<w;x++) temp_1w[x]=in[x]*radius;
    for(int y=0;y<radius+1;y++)
    {
        for(int x=0;x<w;x++)
        {
            temp_1w[x]+=in[y*w+x];
        }
    }
    for(int x=0;x<w;x++) out[x]=T(temp_1w[x]*scale); //NOTE: for integer types, the conversion may possibly cause 0.5 lost!
    for(int y=1;y<radius+1;y++)
    {
        for(int x=0;x<w;x++)
        {
            int c=y*w+x;
            temp_1w[x]+=in[c+radius*w];
            temp_1w[x]-=in[x];
            out[c]=T(temp_1w[x]*scale); //NOTE: for integer types, the conversion may possibly cause 0.5 lost!
        }
    }
    for(int y=radius+1;y<h-radius;y++)
    {
        for(int x=0;x<w;x++)
        {
            int c=y*w+x;
            temp_1w[x]+=in[c+radius*w];
            temp_1w[x]-=in[c-(radius*w)-w];
            out[c]=T(temp_1w[x]*scale); //NOTE: for integer types, the conversion may possibly cause 0.5 lost!
        }
    }
    for(int y=h-radius;y<h;y++)
    {
        for(int x=0;x<w;x++)
        {
            int c=y*w+x;
            temp_1w[x]+=in[(h-1)*w+x];
            temp_1w[x]-=in[c-(radius*w)-w];
            out[c]=T(temp_1w[x]*scale); //NOTE: for integer types, the conversion may possibly cause 0.5 lost!
        }
    }
}


//////////////////////////////////////////////////////////////////////////
// Guided filtering implementation 
template<typename T, typename G>
class bao_guided_filter
{
public:
    bao_guided_filter():m_h(0),m_w(0),m_range_val(BAO_UCHAR_MAX),m_is_only_gray(false),
        m_is_precompute_texture(false),m_buf_d(NULL),m_temp_buf(NULL),m_temp_1w(NULL),m_radius(0),m_eps(0){}
    ~bao_guided_filter(){_destroy();}

public:
    void init(int h,int w,bool is_only_gray=false,G texture_range_val=BAO_UCHAR_MAX)
    {
        _destroy();
        m_h = h;
        m_w = w;
        m_range_val = texture_range_val;
        m_is_only_gray = is_only_gray;
        int buffer_needed = 10; //computation buffer
        m_buf_d = bao_alloc<BAO_FLOAT>(buffer_needed,m_h,m_w);
        m_temp_1w = bao_alloc<BAO_FLOAT>(m_w);
        m_temp_buf = bao_alloc<T>(2,m_h,m_w); //2 image buffer
    }

    void precompute_texture(G**texture,BAO_FLOAT sig_s,BAO_FLOAT sig_r)
    {
        m_is_precompute_texture = true;
        m_radius = (int)bao_round(sig_s); //(int)bao_round(sig_s*min(m_h,m_w));
        m_eps = sig_r*m_range_val;
        m_eps *= m_eps; //NOTE: eps=sig_r^2 (see paper)

        //pre-compute texture
        BAO_FLOAT** temp_d = m_buf_d[0];
        BAO_FLOAT** texture_d = m_buf_d[1];
        BAO_FLOAT** texture_mean = m_buf_d[2];
        bao_copy(texture_d,texture,m_h,m_w);
        bao_box_filtering(texture_mean,texture_d,temp_d,m_temp_1w,m_radius,m_h,m_w); //mean_I
        BAO_FLOAT** texture_square = m_buf_d[3];
        bao_vec_dot_product(texture_square[0],texture_d[0],texture_d[0],m_h*m_w);
        BAO_FLOAT** texture_corr = m_buf_d[4]; //reuse texture_d
        bao_box_filtering(texture_corr,texture_square,temp_d,m_temp_1w,m_radius,m_h,m_w); //corr_I
    }

    void filter(T**img_out,T**img_in,G**texture,BAO_FLOAT sig_s,BAO_FLOAT sig_r) //sig_s is measured by pixel, eps=sig_r^2
    {
        if (!m_is_precompute_texture) precompute_texture(texture,sig_s,sig_r);
        BAO_FLOAT** temp_d = m_buf_d[0];
        BAO_FLOAT** texture_d = m_buf_d[1];
        BAO_FLOAT** texture_mean = m_buf_d[2];
        BAO_FLOAT** img_in_d = m_buf_d[5];
        BAO_FLOAT** img_mean = m_buf_d[6];
        bao_copy(img_in_d,img_in,m_h,m_w);
        bao_box_filtering(img_mean,img_in_d,temp_d,m_temp_1w,m_radius,m_h,m_w); //mean_p
        BAO_FLOAT** texture_square = m_buf_d[3];
        BAO_FLOAT** texture_img_dot = m_buf_d[7];
        bao_vec_dot_product(texture_img_dot[0],texture_d[0],img_in_d[0],m_h*m_w);
        img_in_d = NULL;
        BAO_FLOAT** texture_corr = m_buf_d[4]; //reuse texture_d
        BAO_FLOAT** texture_img_corr = m_buf_d[5]; //reuse img_in_d
        bao_box_filtering(texture_img_corr,texture_img_dot,temp_d,m_temp_1w,m_radius,m_h,m_w); //corr_Ip
        texture_img_dot = NULL;
        BAO_FLOAT** coef_a = m_buf_d[7]; //reuse texture_squre
        BAO_FLOAT** coef_b = m_buf_d[8]; //reuse texture_img_dot
        for(int y=0;y<m_h;y++) for(int x=0;x<m_w;x++) 
        {
            BAO_FLOAT texture_mean_val = texture_mean[y][x];
            BAO_FLOAT img_mean_val = img_mean[y][x];
            BAO_FLOAT texture_var = texture_corr[y][x] - texture_mean_val*texture_mean_val; //var_I
            BAO_FLOAT texture_img_cov = texture_img_corr[y][x] - texture_mean_val*img_mean_val; //cov_Ip
            coef_a[y][x] = texture_img_cov / (texture_var+m_eps); //a
            coef_b[y][x] = img_mean_val - coef_a[y][x]*texture_mean_val; //b
        }
        texture_img_corr = NULL;
        BAO_FLOAT** coef_a_mean = m_buf_d[9]; //reuse texture_corr
        BAO_FLOAT** coef_b_mean = m_buf_d[5]; //reuse texture_img_corr
        bao_box_filtering(coef_a_mean,coef_a,temp_d,m_temp_1w,m_radius,m_h,m_w); //mean_a
        bao_box_filtering(coef_b_mean,coef_b,temp_d,m_temp_1w,m_radius,m_h,m_w); //mean_b
        for(int y=0;y<m_h;y++) for(int x=0;x<m_w;x++) 
        {
            temp_d[y][x]=coef_a_mean[y][x]*texture[y][x]+coef_b_mean[y][x]; //output
        }
        bao_copy(img_out,temp_d,m_h,m_w);
    }

private:
    void _destroy(){bao_free(m_buf_d); bao_free(m_temp_1w); bao_free(m_temp_buf);}

private:
    int  m_h;
    int  m_w;
    G    m_range_val;
    bool m_is_only_gray; //if true, will allocate less memory
    BAO_FLOAT*** m_buf_d;
    BAO_FLOAT*   m_temp_1w;
    T***         m_temp_buf;

private:
    //for pre-computing
    bool m_is_precompute_texture; //if true, pre-compute texture
    int m_radius;
    BAO_FLOAT m_eps;
};


//////////////////////////////////////////////////////////////////////////
// Read, write PPM, PGM file 
int qx_imagesize(char* file_name,int &h,int &w); /*return # of channel*/
int qx_loadimage(char*file_name,unsigned char*image,int h,int w,int *nr_channel=0);
void qx_saveimage(char*file_name,unsigned char*image,int h,int w,int channel);




#endif