% Function to compute TV-L1 optical flow using the Split-Bregman algorithm:
% 
% A Comparison of TV-L1 Optical Flow Solvers on GPU.
% Linchao Bao, Hailin Jin, Byungmoon Kim, and Qingxiong Yang.
% GPU Technology Conference (GTC), 2014. (poster) 
%
% NOTICE: 1. REQUIRE CUDA-capable NVIDIA GPU with compute capability > 2.0
%            (e.g., graphics card GTX 400 series or newer).
%
%         2. The first time running the mex needs to load the mex file into
%            Matlab's process and thus will be slow. For timing, please run
%            the mex for a second time. 
%
%         3. The timing described in the paper does not include device
%            initialization (but here each mex call does). Thus the timing
%            in Matlab will be a little longer than that described in the 
%            paper. 
%
%         4. Tested under Matlab R2013a in Windows 7/8 64-bit. Please
%         update the GPU driver if there is problem running the mex.
%         
%         5. Please contact Linchao Bao (linchaobao@gmail.com) for bugs.
%
% Usage:
%
% uv = TVL1Flow_SB(img1, img2, lambda, num_warp, num_outer, num_inner);
% 
% PARAMS: 
%       img1 and img2: input image should be 3-channel double type.
%       lambda: the balance between data term and smoothness term [20/255].
%       num_warp: number of warping [10].
%       num_outer: number of outer iterations of the solver [20].
%       num_inner: number of inner iterations of the solver [2].
%       uv: output is a 2-channel double type flow field.
% 
% 




