
im1 = imread('frame10.png');
im2 = imread('frame11.png');

im1 = im2double(im1);
im2 = im2double(im2);

tic;
uvsb = TVL1Flow_SB(im1,im2,20.0/255.0,10,20,2);
toc;

% tic;
% uvdl = TVL1Flow_DL(im1,im2,20.0/255.0,10,20,2);
% toc;
% 
% tic;
% uvfp = TVL1Flow_FP(im1,im2,20.0/255.0,10,20,10);
% toc;

writeFlowFile(uvsb,'flowSB.flo');

% writeFlowFile(uvdl,'flowDL.flo');
% writeFlowFile(uvfp,'flowFP.flo');

