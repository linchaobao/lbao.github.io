The Matlab mex file to compute TV-L1 optical flow using the algorithms in:

A Comparison of TV-L1 Optical Flow Solvers on GPU.
Linchao Bao, Hailin Jin, Byungmoon Kim, and Qingxiong Yang.
GPU Technology Conference (GTC), 2014. (poster) 

NOTICE: 1. REQUIRE CUDA 8.0. 

        2. The first time running the mex needs to load the mex file into
           Matlab's process and thus will be slow. For timing, please run
           the mex for a second time. 

        3. The timing described in the paper does not include device
           initialization (but here each mex call does). Thus the timing
           in Matlab will be a little longer than that described in the 
           paper. 

        4. Tested under Matlab R2016a in Windows 7/8 64-bit and Linux. 
        
        5. Please contact Linchao Bao (linchaobao@gmail.com) for bugs.

More information could be found here: https://sites.google.com/site/linchaobao/