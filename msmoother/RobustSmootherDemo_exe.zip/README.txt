The binary executable "qtdemo.exe" is a GUI demo for our manuscript. It is built 
using QT4 and tested under Windows 7 64-bit with Visual Studio 2008 installed. 
Please watch the attached HOWTO video for a quick impression of how to use it. 
The demo is only used for the review purpose. Do not distribute it for other use. 

NOTE: The demo does *NOT* use GPU for acceleration. Please be aware that our 
manuscript reports some timing performance on either CPU or GPU. 

ACKNOWLEDGEMENT: Thanks to Nokia for the QT4 SDK. Thanks to William Baxter for the 
imdebug tool. 


