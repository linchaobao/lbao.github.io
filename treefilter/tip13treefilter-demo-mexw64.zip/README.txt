Usage: see TreeFilterRGB_Uint8.m for details. See demo_filter.m 
and demo_texture_edit.m for two examples. 

Please refer to the following paper for details:

Linchao Bao, Yibing Song, Qingxiong Yang, Hao Yuan, and Gang Wang, 
"Tree Filtering: Efficient Structure-Preserving Smoothing with a 
Minimum Spanning Tree", 
IEEE Transactions on Image Processing, 2014. 

The demo is only for academic use. Note that the timing reported 
in the paper is for single channel image. Please contact with 
linchaobao at gmail dot com for reporting bugs. 
