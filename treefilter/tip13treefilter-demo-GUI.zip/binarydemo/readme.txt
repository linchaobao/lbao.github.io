The binary executable is a GUI demo for tree filtering. It is built using QT4 and tested under Windows 7 64-bit with Visual Studio 2008 installed. The demo is only used for the review of manuscript "Tree Filtering: Efficient Image Smoothing with a Minimum Spanning Tree". Do not distribute it for other use. 

NOTE: The performance of the demo might be degraded by the GUI and thus slower than that reported in the paper. All input images are treated as RGB color images. 

Acknowledgement: Thanks to Nokia for the QT4 SDK. Thanks to William Baxter for the imdebug tool. 


